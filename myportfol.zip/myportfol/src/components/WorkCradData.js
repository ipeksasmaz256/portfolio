import pro1 from "../assets/countdown.png";
import pro2 from "../assets/kanye.png";


const ProjectCardData = [
    {
        imgsrc: pro1,
        title:"Countdown",
        text:"A countdown with basic html/css",
        view: "https://github.com/ipeksasmaz256/countdown"
    },
    {
        imgsrc: pro2,
        title:"Kanye & Taylor ",
        text:"My delusional website about relationship of Kanye and Taylor",
        view: "https://github.com/ipeksasmaz256/kanyetaylor"
    },
];

export default ProjectCardData;